import React from 'react'
import { Example } from './modals/CreateModal'

export const InvoiceC = () => {
  return (
    <div>
      <Example />
    </div>
  )
}
